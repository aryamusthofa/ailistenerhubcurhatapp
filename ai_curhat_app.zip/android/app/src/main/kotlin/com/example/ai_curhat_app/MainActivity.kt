package com.example.ai_curhat_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
