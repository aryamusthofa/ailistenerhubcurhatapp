
class BoxNames {
  static const String chatBox = 'chat_box_encrypted';
  static const String moodBox = 'mood_box_encrypted';
  static const String userBox = 'user_box_encrypted';
}
