enum AiVibe {
  empathetic,
  logical,
  justListen,
  srCounselor,
}
