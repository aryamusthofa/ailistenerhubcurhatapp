
class SecurityConstants {
  static const String secureStorageKey = 'ai_curhat_secure_key';
}
