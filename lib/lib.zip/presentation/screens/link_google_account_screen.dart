import 'package:flutter/material.dart';

class LinkGoogleAccountScreen extends StatelessWidget {
  const LinkGoogleAccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Link Google Account')),
      body: const Center(child: Text('Link Google Account Placeholder')),
    );
  }
}
