import 'package:flutter/material.dart';

class UIConstants {
  static const BorderRadius glassBorderRadius = BorderRadius.all(Radius.circular(16));
}
